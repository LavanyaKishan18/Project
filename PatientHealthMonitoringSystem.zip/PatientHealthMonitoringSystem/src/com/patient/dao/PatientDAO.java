package com.patient.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.patient.model.BMI;
import com.patient.model.BloodCount;
import com.patient.model.Diabetics;
import com.patient.model.Glucose;
import com.patient.model.Patient;

public class PatientDAO {
	String url = "jdbc:mysql://localhost:3306/patient";
	String username = "root";
	String password = "root";
	int result = 0;

	public int registerPatient(Patient p) {

		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(url, username,
					password);
			PreparedStatement pstmt = con
					.prepareStatement("insert into patient values(?,?,?,?,?,?,?,?,?,?)");
			pstmt.setString(1, p.getFirstName());
			pstmt.setString(2, p.getLastName());
			pstmt.setInt(3, p.getAge());
			pstmt.setString(4, p.getGender());
			pstmt.setInt(5, p.getContactNumber());
			pstmt.setString(6, p.getEmailAddress());
			pstmt.setString(7, p.getCity());
			pstmt.setString(8, p.getState());
			pstmt.setString(9, p.getUserId());
			pstmt.setString(10, p.getPassword());
			result = pstmt.executeUpdate();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;

		// System.out.println(c.getCustomerName());
	}

	public int registerDoctor(Patient p) {

		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(url, username,
					password);
			PreparedStatement pstmt = con
					.prepareStatement("insert into doctor1 values(?,?,?,?,?,?,?,?,?,?)");
			pstmt.setString(1, p.getFirstName());
			pstmt.setString(2, p.getLastName());
			pstmt.setInt(3, p.getAge());
			pstmt.setString(4, p.getGender());
			pstmt.setInt(5, p.getContactNumber());
			pstmt.setString(6, p.getEmailAddress());
			pstmt.setString(7, p.getCity());
			pstmt.setString(8, p.getState());
			pstmt.setString(9, p.getUserId());
			pstmt.setString(10, p.getPassword());
			result = pstmt.executeUpdate();
		} catch (ClassNotFoundException | SQLException e) {

			e.printStackTrace();
		}
		return result;

		// System.out.println(c.getCustomerName());
	}

	public int addBMI(BMI b) {

		try {

			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(url, username,
					password);
			String sql = "insert into calculated_bmi values(?,?,?,?)";
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setDouble(2, b.getHeight());
			pstmt.setDouble(3, b.getWeight());
			pstmt.setDouble(4, b.getBmi());
			pstmt.setString(1, b.getId());
			result = pstmt.executeUpdate();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;

		// System.out.println(c.getCustomerName());
	}

	public BMI display(String userid) throws Exception

	{
		BMI b = null;

		try {

			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(url, username,
					password);

			Statement stmt = con.createStatement();
			String sql = "select * from calculated_BMI where id=" + userid;

			ResultSet result = stmt.executeQuery(sql);
			if (result.next()) {
				b = new BMI();
				b.setId(result.getString(1));
				b.setHeight(result.getDouble(2));
				b.setWeight(result.getDouble(3));
				b.setBmi(result.getDouble(4));
			}

		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return b;

	}

	public int addGlucose(Glucose g) {

		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(url, username,
					password);
			PreparedStatement pstmt = con
					.prepareStatement("insert into glucose values(?,?,?)");
			pstmt.setLong(1, g.getPatientId());
			pstmt.setString(2, g.getTimeOfTheDay());
			pstmt.setString(3, g.getBloodGlucoseLevel());
			result = pstmt.executeUpdate();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;

		// System.out.println(c.getCustomerName());
	}

	public int addBloodCount(BloodCount bc) {

		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(url, username,
					password);
			PreparedStatement pstmt = con
					.prepareStatement("insert into bloodcount values(?,?,?,?,?)");
			pstmt.setLong(1, bc.getPatientId());
			pstmt.setString(2, bc.getTimeOfTheDay());
			pstmt.setString(3, bc.getRbcCount());
			pstmt.setString(4, bc.getWbcCount());
			pstmt.setString(5, bc.getPlateletCount());
			result = pstmt.executeUpdate();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;

		// System.out.println(c.getCustomerName());
	}

	public Patient getPatientById(String userid) {
		Patient p1 = null;
		// TODO Auto-generated method stub
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(url, username,
					password);
			PreparedStatement pstmt = con
					.prepareStatement("select * from patient where userid=?");
			pstmt.setString(1, userid);
			// ResultSet rs=(ResultSet) pstmt.executeQuery();

			ResultSet rs1 = (ResultSet) pstmt.executeQuery();
			if (rs1 != null) {
				rs1.next();
				p1 = new Patient();
				p1.setFirstName(rs1.getString(1));
				p1.setLastName(rs1.getString(2));
				p1.setAge(rs1.getInt(3));
				p1.setGender(rs1.getString(4));
				p1.setContactNumber(rs1.getInt(5));
				p1.setEmailAddress(rs1.getString(6));
				p1.setCity(rs1.getString(7));
				p1.setState(rs1.getString(8));
				p1.setUserId(rs1.getString(9));
				p1.setPassword(rs1.getString(10));

			}
		} catch (ClassNotFoundException | SQLException e) {

			e.printStackTrace();
		}
		return p1;
	}

	public int updatePatient(Patient p) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(url, username,
					password);
			PreparedStatement pstmt = con
					.prepareStatement("update patient set firstname=?,lastname=?,age=?,gender=?,contactnumber=?,emailaddress=?,city=?,state=?,password=? where userid=?");

			pstmt.setString(1, p.getFirstName());
			pstmt.setString(2, p.getLastName());

			pstmt.setInt(3, p.getAge());
			pstmt.setString(4, p.getGender());
			pstmt.setInt(5, p.getContactNumber());
			pstmt.setString(6, p.getEmailAddress());
			pstmt.setString(7, p.getCity());
			pstmt.setString(8, p.getState());
			pstmt.setString(9, p.getPassword());
			pstmt.setString(10, p.getUserId());

			result = pstmt.executeUpdate();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;

	}

	public boolean doctorLoginValidate(String pId, String ppass) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(url, username,
					password);
			PreparedStatement pstmt = con
					.prepareStatement("select * from doctor1 where userid=? and password=?");
			pstmt.setString(1, pId);
			pstmt.setString(2, ppass);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				return true;
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}

	public boolean patientLoginValidate(String pId, String ppass) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(url, username,
					password);
			PreparedStatement pstmt = con
					.prepareStatement("select * from patient where userid=? and password=?");
			pstmt.setString(1, pId);
			pstmt.setString(2, ppass);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				return true;
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}

	public int DiabeticsInsert(Diabetics dia) throws SQLException
	{
		int status=0;
		
			try {
				Class.forName("com.mysql.jdbc.Driver");
				Connection con = DriverManager.getConnection(url, username,
						password);
				String sql="insert into diabetics values(?,?,?,?,?,?,?)";
				PreparedStatement pstmt=con.prepareStatement(sql);
				pstmt.setString(1, dia.getUserId());
				pstmt.setDouble(2, dia.getHeight());
				pstmt.setDouble(3, dia.getWeight());
				pstmt.setInt(4, dia.getAge());
				pstmt.setString(5,dia.getGlucoseLevel());
				pstmt.setString(6, dia.getDiabeticsLevel());
				pstmt.setString(7, dia.getDate());
				
				
				status=pstmt.executeUpdate();
				
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
			
		
		
		
		return status;
	}
	public Diabetics Diabetics(String userid) {
		Diabetics dia=new Diabetics();
		int age=0;
		double height=0,weight=0;
		String glevel="",d="",date="";

		try {

			 
			System.out.println("diablets dao starts"+ userid);
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(url, username,
					password);
			String sql="select age from patient where userid=?";
			PreparedStatement pstmt=con.prepareStatement(sql);
			pstmt.setString(1,userid);
			ResultSet rs= pstmt.executeQuery();
			while(rs.next())
			{
				age=rs.getInt(1);
			}
			System.out.println("patient table");
			String sql1="select height,weight from calculated_bmi where id=?";
			PreparedStatement pstmt1=con.prepareStatement(sql1);
			pstmt1.setString(1,userid);
			ResultSet rs1= pstmt1.executeQuery();
			while(rs1.next())
			{
				height=rs1.getDouble(1);
				weight=rs1.getDouble(2);
			}
			System.out.println("bmi table");
			String sql2="select bloodglucoselevel,timeoftheday from glucose where patientid=?";
			PreparedStatement pstmt2=con.prepareStatement(sql2);
			pstmt2.setString(1,userid);
			ResultSet rs2= pstmt2.executeQuery();
			
			while(rs2.next())
			{
				glevel=rs2.getString(1);
				date=rs2.getString(2);
			}
			System.out.println("glucose table");
		if(age>=18 && age<=35)
			{
				
				if(height<100 && weight<100){
					if(glevel.equals("120")){
						d="Monthly";
					}
				}
				else if(height>=100 && weight>=100){
					if(glevel.equals("120")){
						d="Once/2Months";
					}
				}
				else if(height<100 && weight<100){
					if(glevel.equals("80-120")){
						d="Once/2Months";
					}
				}
				else if(height>=100 && weight>=100){
					if(glevel.equals("80-120")){
						d="Once/3Months";
					}
				}
				else
				{
					d="Monthly";
				}
			}
			else if(age>=36 && age<=60)
			{
				if(height<100 && weight<100){
					if(glevel.equals("120")){
						d="Monthly";
					}
				}
				else if(height>=100 && weight>=100){
					if(glevel.equals("120")){
						d="Once/2Months";
					}
				}
				else if(height<100 && weight<100){
					if(glevel.equals("80-120")){
						d="Once/2Months";
					}
				}
				else if(height>=100 && weight>=100){
					if(glevel.equals("80-120")){
						d="Once/3Months";
					}
				}
				else
				{
					d="Monthly";
				}
					
			}
			else if(age>=61 && age<=90)
			{
				if(height<100 && weight<100){
					if(glevel.equals("120")){
						d="Twice/Month";
					}
				}
				else if(height>=100 && weight>=100){
					if(glevel.equals("120")){
						d="Twice/Month";
					}
				}
				else if(height<100 && weight<100){
					if(glevel.equals("80-120")){
						d="Monthly";
					}
				}
				else if(height>=100 && weight>=100){
					if(glevel.equals("80-120")){
						d="Monthly";
					}
				}
				else
				{
					d="Monthly";
				}
			}
			else if(age>=91 && age<=120)
			{
				if(height<100 && weight<100){
					if(glevel.equals("120")){
						d="Weekly";
					}
				}
				else if(height>=100 && weight>=100){
					if(glevel.equals("120")){
						d="Weekly";
					}
				}
				else if(height<100 && weight<100){
					if(glevel.equals("80-120")){
						d="Twice/Month";
					}
				}
				else if(height>=100 && weight>=100){
					if(glevel.equals("80-120")){
						d="Twice/Month";
					}
				}
				else
				{
					d="Monthly";
				}
				
			}
			
			
			
			dia.setUserId(userid);
			dia.setHeight(height);
			dia.setWeight(weight);
			dia.setAge(age);
			dia.setGlucoseLevel(glevel);
			dia.setDiabeticsLevel(d);
			dia.setDate(date);
			System.out.println("diablets daoends");
		} 
		catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return dia;
	}

	public Diabetics displayDia(String uid) {
		Diabetics dia = null;

		try {

			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(url, username,
					password);

			Statement stmt = con.createStatement();
			String sql = "select * from diabetics where userId=" + uid;

			ResultSet result = stmt.executeQuery(sql);
			if (result.next()) {
				dia = new Diabetics();
				dia.setUserId(result.getString(1));
				dia.setHeight(result.getDouble(2));
				dia.setWeight(result.getDouble(3));
				dia.setAge(result.getInt(4));
				dia.setGlucoseLevel(result.getString(5));
				dia.setDiabeticsLevel(result.getString(6));
			}

		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return dia;
	}

	public int updateBMI(BMI b) {
		int result = 0;
		try {

			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(url, username,password);
			PreparedStatement pstmt = con.prepareStatement("update calculated_bmi set height=?,weight=?,bmi=? where id=?");
			pstmt.setDouble(1,b.getHeight());
			pstmt.setDouble(2, b.getWeight());
			pstmt.setDouble(3, b.getBmi());
			pstmt.setString(4, b.getId());
			result = pstmt.executeUpdate();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}

	public int updateGlucose(Glucose g) {
	
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(url, username,password);
			PreparedStatement pstmt = con
					.prepareStatement("update glucose set timeoftheday=?,bloodglucoselevel=? where patientid=?");
			pstmt.setLong(3, g.getPatientId());
			pstmt.setString(1, g.getTimeOfTheDay());
			pstmt.setString(2, g.getBloodGlucoseLevel());
			result = pstmt.executeUpdate();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}
}
