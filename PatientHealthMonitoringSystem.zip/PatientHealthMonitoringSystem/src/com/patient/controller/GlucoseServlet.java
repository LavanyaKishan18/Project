package com.patient.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.patient.dao.PatientDAO;
import com.patient.model.BMI;
import com.patient.model.Glucose;


@WebServlet("/GlucoseServlet")
public class GlucoseServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session = request.getSession();
		String patientId = (String)(session.getAttribute("uId"));
		System.out.println(patientId);
		String timeOfTheDay=request.getParameter("ptime");
		System.out.println(timeOfTheDay);
		String bloodGlucoseLevel=request.getParameter("pglucose");
		System.out.println(bloodGlucoseLevel);
		Glucose g=new Glucose();
		g.setPatientId(Integer.parseInt((patientId)));
		g.setTimeOfTheDay(timeOfTheDay);
		g.setBloodGlucoseLevel(bloodGlucoseLevel);
		PatientDAO pdao=new PatientDAO();
		int status=pdao.addGlucose(g);
		if(status!=0){
			
			RequestDispatcher rd=request.getRequestDispatcher("g.html");
			HttpSession hs=request.getSession();
			rd.forward(request, response);
			hs.setAttribute("glucose", bloodGlucoseLevel);
	}else{
		RequestDispatcher rd=request.getRequestDispatcher("glucose.jsp");
		rd.forward(request, response);
	}
		
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
