package com.patient.controller;


import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.patient.dao.PatientDAO;
import com.patient.model.Patient;

@WebServlet("/RegisterDoctorServlet")
public class RegisterDoctorServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String firstName=request.getParameter("pfirstname");
		System.out.println(firstName);
		String lastName=request.getParameter("plastname");
		System.out.println(lastName);
		int  age=Integer.parseInt(request.getParameter("page"));
		System.out.println(age);
		String gender=request.getParameter("pgender");
		System.out.println(gender);
		String contactNumber=request.getParameter("pcontactnumber");
		System.out.println(contactNumber);
		String emailAddress=request.getParameter("pemailaddress");
		System.out.println(emailAddress);
		String city=request.getParameter("pcity");
		System.out.println(city);
		String state=request.getParameter("pstate");
		System.out.println(state);
		String userId=request.getParameter("puserid");
		System.out.println(userId);
		String password=request.getParameter("ppassword");
		System.out.println(password);
		Patient p=new Patient();
		p.setFirstName(firstName);
		p.setLastName(lastName);
		p.setAge(age);
		p.setGender(gender);
		p.setContactNumber(Integer.parseInt(contactNumber));
		p.setEmailAddress(emailAddress);
		p.setCity(city);
		p.setState(state);
		p.setUserId((userId));
		p.setPassword(password);
		
		PatientDAO pdao=new PatientDAO();
		int status=pdao.registerDoctor(p);
		if(status!=0){
			RequestDispatcher rd=request.getRequestDispatcher("login.jsp");
			rd.forward(request, response);
	}else{
		RequestDispatcher rd=request.getRequestDispatcher("register.jsp");
		rd.forward(request, response);
	}
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

}
